from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.models import Person

# Create your views here.
def index(request):
    all_Person = Person.objects.all()
    return render(request,'index.html',{"all_person":all_Person})

def about(request):
    return render(request,'about.html')

def form(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        name = request.POST.get("name")
        age = request.POST.get("age")
        address = request.POST.get("address")
        phone_number = request.POST.get("phone_number")

        person = Person.objects.create(
            first_name=first_name,
            last_name=last_name,
            name=name,
            age=age,
            address=address,
            phone_number=phone_number
        )
        return redirect("/")
    else:
        return render(request, "form.html")