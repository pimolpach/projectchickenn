from django.db import models

class Person(models.Model):
    first_name = models.CharField(max_length=100)       # ชื่อจริง
    last_name = models.CharField(max_length=100)        # นามสกุล
    name = models.CharField(max_length=100)             # ชื่อเล่นหรือชื่ออื่น ๆ
    age = models.IntegerField()                         # อายุ
    address = models.TextField()                        # ที่อยู่
    phone_number = models.CharField(max_length=15)      # เบอร์โทรศัพท์
    data = models.DateTimeField(auto_now_add=True)      # วันเวลาเพิ่มข้อมูล

    def __str__(self):
        return f"{self.first_name} {self.last_name}"